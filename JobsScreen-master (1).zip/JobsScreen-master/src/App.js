import React from 'react';
import Body from './Componets/Home/body';



export default () => {
  return (
    <>
      <Body/>
    </>
    );
}