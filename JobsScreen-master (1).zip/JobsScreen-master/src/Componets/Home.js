import React from 'react';
import Body from './Home/body'


export default () => {
  return (
    <>
      <Body />
    </>
    );
}